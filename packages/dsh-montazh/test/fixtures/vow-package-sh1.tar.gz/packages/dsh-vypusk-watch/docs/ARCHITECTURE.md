# Архитектура · Architecture — dsh-vypusk-watch

## Состав · Components

| Файл · File | Что · What |
|---|---|
| `src/vypusk-okno-watch.sh` | сторож: bash с десятью встроенными программами на Python (heredoc) · the watchdog: bash with ten embedded Python programs (heredoc) |
| `test/probe.py` + `stend-kopij-vypuska.sh` | стенд копий выпуска и сверка снимка с установленным файлом · release-copy stand and snapshot-vs-installed check |
| `test/stend-sootvetstviya.py` + `.sh` | стенд пар соответствия · correspondence-pair stand |
| `test/stend-svoej-metki.py` + `.sh` | договор «бой = своему выпуску» · "production = own release" contract |
| `test/stend-prezhnih-imen.py` + `.sh` | прежние имена пакета (`dsh.prezhnie_imena`) · former package names |
| `test/stend-dovodov.sh` | отказ на неподдерживаемый довод · refusal on an unsupported argument |

Поимённый перечень 14 входов; Python-тело shell-обёртки отдельно не считается.

Named inventory of 14 entry points; a shell wrapper and its Python body count once.

| Вход · Entry |
|---|
| `test/stend-audit-docs.py` |
| `test/stend-audit-runtime.py` |
| `test/stend-derevo.sh` |
| `test/stend-dovodov.sh` |
| `test/stend-kopij-vypuska.sh` |
| `test/stend-montazh-okno.py` |
| `test/stend-nastroek.sh` |
| `test/stend-neskolko-kopij.sh` |
| `test/stend-pochinki.sh` |
| `test/stend-prezhnih-imen.sh` |
| `test/stend-pustoj-zapisi.sh` |
| `test/stend-raskladki.sh` |
| `test/stend-sootvetstviya.sh` |
| `test/stend-svoej-metki.sh` |

## Один прогон · One run

```mermaid
flowchart TB
    A["старт · start"] --> B{"есть доводы? · arguments?"}
    B -- иной · unsupported --> X3["ОТКАЗ, код 3 · REFUSAL, exit 3"]
    B -- нет/--avto-montazh · none/--avto-montazh --> C{"дерево с .git есть? · tree with .git?"}
    C -- нет · no --> S2["слепота → тревога, код 2 · blindness → alarm, exit 2"]
    C -- да · yes --> D["корни: основные, добавочные, чужие; исключения CHANGELOG · roots: main, extra, foreign; CHANGELOG exceptions"]
    D --> E["для каждого пакета дерева · for each tree package"]
    E --> F{"боевая копия найдена? · production copy found?"}
    F -- нет · no --> VNE["вне области — перечислить · out of scope — list"]
    F -- да · yes --> G["версия боя → своя метка &lt;имя&gt;-v&lt;версия&gt; · production version → own tag"]
    G --> H{"метка одна? · exactly one tag?"}
    H -- "нет, выпуски известны · none, releases known" --> R["расхождение · divergence"]
    H -- "нет меток / две · no tags / two" --> SL["слепота пакета · package blindness"]
    H -- да · yes --> I["суммы метки и боя по режиму счёта; CHANGELOG; состав · tag and production checksums by counting mode; CHANGELOG; file list"]
    I --> J{"всё совпало? · all match?"}
    J -- да · yes --> OK["сошлось · matched"]
    J -- нет · no --> R
    OK & R & SL & VNE --> K["ссылки монтажа · install symlinks"]
    K --> L{"итог · result"}
    L -- "расхождения есть · divergences" --> M["тревога, если картина новая или прошло NAPOMINAT; код 1 · alarm if picture is new or NAPOMINAT passed; exit 1"]
    L -- "только слепота · only blindness" --> S2
    L -- "чисто · clean" --> Z["молча, код 0 · silent, exit 0"]
```

Слепота — отдельный предмет: «сверять нечем» не смешивается с «разошлось». Ранняя слепота (нет дерева, исключения не прочитаны, корень нечитаем) обрывает прогон сразу; поздняя (у отдельных пакетов) собирается в итог.

Blindness is a separate subject: "nothing to compare against" is never mixed with "diverged". Early blindness (no tree, exceptions unreadable, an unreadable root) aborts the run at once; late blindness (for individual packages) is collected into the result.

## Сверка одного пакета · Checking one package

```mermaid
sequenceDiagram
    participant W as Сторож · Watchdog
    participant G as git (дерево · tree)
    participant L as Боевой каталог · Production dir
    W->>L: package.json → версия · version
    W->>G: git tag --list → свои метки и все выпуски · own tags and all releases
    W->>G: git archive &lt;метка&gt; packages/&lt;каталог&gt; → временный каталог · tag files → temp dir
    W->>W: суммы метки по режиму счёта · tag checksums by counting mode
    W->>L: суммы боя по тому же режиму · production checksums, same mode
    W->>W: сравнить множества; состав из manifest files · compare sets; file list from manifest
    W->>W: CHANGELOG: запись версии в бою и в метке · CHANGELOG: version entry in production and tag
    W-->>W: сошлось / разошлось (до 6 имён файлов с каждой стороны) · matched / diverged (up to 6 file names per side)
```

Дерево обязано иметь раскладку `packages/<каталог>`: файлы метки берутся `git archive` именно оттуда. Идентичность пакета — имя каталога в дереве, а не `package.name` и не текст диагностики. Метка своей версии — `<каталог>-v<версия>` или `<имя пакета>-v<версия>`, также по `dsh.prezhnie_imena`; если таких несколько — слепота.

The tree must use the `packages/<directory>` layout: tag files are taken from there with `git archive`. Package identity is the directory name in the tree, not `package.name` and not the diagnostic text. The own-version tag is `<directory>-v<version>` or `<package name>-v<version>`, also by `dsh.prezhnie_imena`; more than one such tag is blindness.

## Подавление повторов · Repeat suppression

```mermaid
stateDiagram-v2
    [*] --> Новая: расхождение · divergence
    Новая --> Отправлена: канал код 0 → отметка (отпечаток по суммам, время) · channel exit 0 → mark (checksum fingerprint, time)
    Новая --> Не_подтверждена: канал отказал или истёк предел 90+5 с · channel failed or 90+5 s limit expired
    Не_подтверждена --> Новая: следующий прогон пробует снова · next run retries
    Отправлена --> Тихо: та же картина, моложе NAPOMINAT · same picture, younger than NAPOMINAT
    Тихо --> Новая: картина изменилась или прошло NAPOMINAT · picture changed or NAPOMINAT passed
    Отправлена --> [*]: расхождений нет · no divergences
```

Отметка доставки пишется только после кода 0 канала, атомарно (временный файл → `mv`). Не сохранилась — следующий прогон может повторить тревогу, и это сказано в выводе.

The delivery mark is written only after channel exit 0, atomically (temp file → `mv`). If it could not be saved, the next run may repeat the alarm, and the output says so.

<a id="install"></a>
## Пример установки · Sample installation

```ini
# /etc/systemd/system/vypusk-okno-watch.service
[Service]
Type=oneshot
User=root
ExecStart=/usr/local/sbin/vypusk-okno-watch.sh
# 1 — расхождение, 2 — слепота: это находки, а не сбой службы · 1 is divergence, 2 is blindness: findings, not a service failure
SuccessExitStatus=0 1 2
# «-»: нет файла — служба стартует, а сторож сам скажет СЛЕПОТУ «не задана настройка» · "-": no file — the service starts and the watchdog itself reports blindness "setting not set"
EnvironmentFile=-/etc/vypusk-okno-watch.env

# /etc/vypusk-okno-watch.env — восемь обязательных настроек и явный путь исключений; пусто выключает необязательную проверку · eight required settings and an explicit exception path; empty disables optional checks
VYPUSK_REPO=<рабочее-дерево · working-tree>
VYPUSK_KORNI=<каталог-плагинов · plugins-dir>/node_modules:<каталог-плагинов · plugins-dir>
VYPUSK_AGENT_POISK=<родитель-домов-агентов · agent-homes-parent>
VYPUSK_INFO_KORNI=
VYPUSK_SOOTVETSTVIYA=
VYPUSK_SSYLKI=
VYPUSK_RASKLADKA=
VYPUSK_REESTR=
VYPUSK_ISKLYUCHENIYA=/usr/local/sbin/vypusk-okno-watch.exceptions.list

# /etc/systemd/system/vypusk-okno-watch.timer
[Timer]
OnBootSec=10min
OnUnitActiveSec=15min
Persistent=true
[Install]
WantedBy=timers.target
```

Расписание выше — то, что стоит у авторов (через 10 минут после загрузки, затем каждые 15 минут). Таймер в пакет не входит; `systemd/vypusk-okno-watch.service` — другой образец, с `--avto-montazh`, требует настройки окружения через drop-in.

The schedule above is the authors' one (10 minutes after boot, then every 15 minutes). The timer is not part of the package; `systemd/vypusk-okno-watch.service` is another sample using `--avto-montazh`, and needs an environment drop-in.

Раскладка не устанавливает `README.md`, `CHANGELOG.md`, `LICENSE`, `docs/`, `test/`; реестр сверяется только по разделам `plugins` и `services`. Описание `derevo` — в `dsh-montazh`.

The layout excludes `README.md`, `CHANGELOG.md`, `LICENSE`, `docs/`, `test/`; registry comparison reads only `plugins` and `services`. See `dsh-montazh` for `derevo`.

Несколько пар в systemd `EnvironmentFile` — значение в двойных кавычках с переводами строк, не пары через пробел. Пример формы (замени все пути на свои):

Multiple pairs in a systemd `EnvironmentFile` use a double-quoted multiline value, not space-separated pairs. Example shape (replace every path):

```ini
VYPUSK_SOOTVETSTVIYA="demo=/srv/copyA:/srv/copyB
other=/srv/other"
VYPUSK_SSYLKI="/srv/plugins/linkA=../demo
/srv/plugins/linkB=../other"
```

## Автоматическая отсрочка · Automatic deferral

`--avto-montazh` — единственный разрешённый ключ, включает адресную отсрочку через `MONTAZH_OKNO_BIN` (умолчание `/usr/local/sbin/montazh-okno`, пакет `dsh-montazh`). Ручной вызов без ключа остаётся строгим. Отсрочка применяется только к невыпущенной версии копии и разрешённым расхождениям сумм `derevo`, когда каждый предмет покрыт действующим окном; права, владельцы и другие строгие дефекты не откладываются. Код 4 — «отложено», не «сошлось»; код 1/2 имеет приоритет. При смене срока/поколения — максимум один пересъём, повторная смена даёт слепоту 2. При автоматическом режиме оператор добавляет 4 в `SuccessExitStatus`, чтобы отсрочка не читалась как сбой службы.

`--avto-montazh` is the only accepted flag; it enables addressed deferral through `MONTAZH_OKNO_BIN` (default `/usr/local/sbin/montazh-okno`, supplied by `dsh-montazh`). Manual invocation stays strict. Only an unreleased copy version and eligible `derevo` checksum differences may be deferred when every subject has an active window; permissions, ownership and other strict defects remain strict. Exit 4 means deferred, not matched; exit 1/2 takes precedence. Expiry/generation changes permit at most one resample; another change is blindness 2. Operators using automatic mode add 4 to `SuccessExitStatus` so deferral is not presented as a unit failure.
